#!/bin/bash
cd theRestaurant_Table/src
javac */*.java
java serverSide.TableMain trash $1 $2