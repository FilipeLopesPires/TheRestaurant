#!/bin/bash
cd theRestaurant_Kitchen/src
javac */*.java
java serverSide.KitchenMain trash $1 $2