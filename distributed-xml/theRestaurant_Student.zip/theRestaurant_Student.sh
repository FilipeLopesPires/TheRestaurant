#!/bin/bash
cd theRestaurant_Student/src
javac */*.java
java clientSide.StudentMain trash $1 $2 $3 $4 $5 $6