/**
 *  Server's side - Solution for the Restaurant's Problem, implementing the client-server model 
 *  of type 2 (server replication) with static launching of the entities envolved.
 */
package serverSide;
