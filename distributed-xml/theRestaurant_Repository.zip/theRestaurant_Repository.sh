#!/bin/bash
cd theRestaurant_Repository/src
javac */*.java
java serverSide.RepoMain