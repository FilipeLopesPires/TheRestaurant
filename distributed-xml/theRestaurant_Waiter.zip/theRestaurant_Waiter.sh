#!/bin/bash
cd theRestaurant_Waiter/src
javac */*.java
java clientSide.WaiterMain trash $1 $2 $3 $4 $5 $6 $7 $8