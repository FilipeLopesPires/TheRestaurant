#!/bin/bash
cd theRestaurant_Bar/src
javac */*.java
java serverSide.BarMain trash $1 $2