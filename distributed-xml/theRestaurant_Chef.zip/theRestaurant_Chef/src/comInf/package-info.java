/**
 *  Common Infrastructures - Solution for the Restaurant's Problem, implementing the client-server model 
 *  of type 2 (server replication) with static launching of the entities envolved.
 *  Communication is based on sending/receiving messages through sockets using TCP Protocol.
 */
package comInf;
