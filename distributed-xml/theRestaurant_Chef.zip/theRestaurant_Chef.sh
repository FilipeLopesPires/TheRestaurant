#!/bin/bash
cd theRestaurant_Chef/src
javac */*.java
java clientSide.ChefMain trash $1 $2 $3 $4 $5 $6